
var cur=0,TOTAL=5,bflyTimer=null,bflyRunning=false;
var pages=document.querySelectorAll('.page');
var dots=document.querySelectorAll('.dot');
var sideP=document.getElementById('side-prev');
var sideN=document.getElementById('side-next');
var WEDDING=new Date('2026-06-24T08:00:00');
var doorState={ds2:false,ds3:false,ds4:false};

/* ── NAV ── */
function goTo(idx){
  if(idx<0||idx>=TOTAL)return;
  var prev=cur;
  pages[prev].classList.remove('active');
  pages[prev].classList.add('exit-left');
  dots[prev].classList.remove('active');
  cur=idx;
  pages[cur].classList.remove('exit-left');
  pages[cur].classList.add('active');
  dots[cur].classList.add('active');
  setTimeout(function(){pages[prev].classList.remove('exit-left');},700);
  pages[cur].scrollTop=0;
  sideP.classList.toggle('hidden',cur===0);
  sideN.classList.toggle('hidden',cur===TOTAL-1);
  if(cur===1)applyDoor('ds2');
  if(cur===2)applyDoor('ds3');
  if(cur===3)applyDoor('ds4');
  if(cur===4){updateCountdown();setTimeout(function(){if(!fwCanvas)initFireworks();},300);}
  if(cur===0)startBfly();else stopBfly();
  setTimeout(function(){burstSparkles(window.innerWidth/2,window.innerHeight/2.5,4);},200);
}
sideP.addEventListener('click',function(){goTo(cur-1);});
sideN.addEventListener('click',function(){goTo(cur+1);});
document.querySelectorAll('.dot').forEach(function(d,i){
  d.addEventListener('click',function(){goTo(i);});
});
document.getElementById('restart-btn').addEventListener('click',function(){
  resetAllDoors();
  document.querySelectorAll('.ev-grid-card.flipped').forEach(function(c){c.classList.remove('flipped');});
  goTo(0);
});

/* ── KEYBOARD ── */
document.addEventListener('keydown',function(e){
  if(document.getElementById('cel-popup').classList.contains('show'))return;
  if(e.key==='ArrowRight'||e.key==='ArrowDown')goTo(cur+1);
  if(e.key==='ArrowLeft'||e.key==='ArrowUp')goTo(cur-1);
});

/* ── SWIPE ── */
var swX=null,swY=null;
document.addEventListener('touchstart',function(e){
  swX=e.touches[0].clientX;swY=e.touches[0].clientY;
},{passive:true});
document.addEventListener('touchend',function(e){
  if(swX===null)return;
  var dx=e.changedTouches[0].clientX-swX,dy=Math.abs(e.changedTouches[0].clientY-swY);
  if(Math.abs(dx)>45&&dy<90){dx<0?goTo(cur+1):goTo(cur-1);}
  swX=null;
},{passive:true});

/* ── MOUSE DRAG ── */
var mDragX=null,mDrag=false;
document.addEventListener('mousedown',function(e){mDragX=e.clientX;mDrag=true;});
document.addEventListener('mouseup',function(e){
  if(!mDrag||mDragX===null)return;
  var dx=e.clientX-mDragX;
  if(Math.abs(dx)>60){dx<0?goTo(cur+1):goTo(cur-1);}
  mDrag=false;mDragX=null;
});
document.addEventListener('mouseleave',function(){mDrag=false;mDragX=null;});

/* ── DOORS ── */
['ds2','ds3','ds4'].forEach(function(id){
  document.getElementById(id).addEventListener('click',function(){openDoor(id);});
});
function openDoor(id){
  if(doorState[id])return;
  doorState[id]=true;applyDoor(id);
  setTimeout(function(){
    var r=document.getElementById(id).getBoundingClientRect();
    burstSparkles(r.left+r.width/2,r.top+r.height*.4,22);
    spawnPetal();
  },950);
}
function applyDoor(id){
  var s=document.getElementById(id),n=id.slice(-1);
  var l=document.getElementById('dh'+n+'L'),r=document.getElementById('dh'+n+'R');
  if(doorState[id]){
    s.classList.add('opened');
    l&&l.classList.add('open');r&&r.classList.add('open');
  }else{
    s.classList.remove('opened');
    l&&l.classList.remove('open');r&&r.classList.remove('open');
  }
}
function resetAllDoors(){
  Object.keys(doorState).forEach(function(k){doorState[k]=false;applyDoor(k);});
}

/* ── BUTTERFLIES ── */
var bflyL=document.getElementById('bfly-L');
var bflyR=document.getElementById('bfly-R');
function triggerBfly(){
  bflyL.classList.remove('flying-l');bflyR.classList.remove('flying-r');
  bflyL.style.animation='none';bflyR.style.animation='none';
  void bflyL.offsetWidth;void bflyR.offsetWidth;
  bflyL.style.animation='';bflyR.style.animation='';
  bflyL.classList.add('flying-l');bflyR.classList.add('flying-r');
}
function startBfly(){
  if(bflyRunning)return;bflyRunning=true;
  triggerBfly();
  bflyTimer=setInterval(function(){
    if(cur!==0){stopBfly();return;}triggerBfly();
  },11000);
}
function stopBfly(){
  clearInterval(bflyTimer);bflyTimer=null;bflyRunning=false;
  bflyL.classList.remove('flying-l');bflyR.classList.remove('flying-r');
}
startBfly();

/* ── COUNTDOWN ── */
function calcCountdown(){
  var diff=WEDDING-new Date();
  if(diff<=0)return{d:'00',h:'00',m:'00',s:'00'};
  var p=function(n){return String(Math.floor(n)).padStart(2,'0');};
  return{d:p(diff/86400000),h:p((diff%86400000)/3600000),
    m:p((diff%3600000)/60000),s:p((diff%60000)/1000)};
}
function updateCountdown(){
  var c=calcCountdown();
  ['d','h','m','s'].forEach(function(k){
    var el=document.getElementById('cd-'+k);if(el)el.textContent=c[k];
  });
}
setInterval(function(){if(cur===4)updateCountdown();},1000);

/* ── POPUP ── */
document.getElementById('cel-btn').addEventListener('click',function(){
  document.getElementById('cel-popup').classList.add('show');
  // Popup is already shown by .show class added just before this
  // Start fireworks with tiny delay so popup renders first
  setTimeout(function(){
    initFireworks();
    startFireworks();
  }, 50);
});
function closePopup(){
  document.getElementById('cel-popup').classList.remove('show');
  clearFireflies();
}
document.getElementById('popup-x').addEventListener('click',closePopup);
document.getElementById('cel-popup').addEventListener('click',function(e){
  if(e.target===document.getElementById('cel-popup'))closePopup();
});

var flyElems=[];
function addFireflies(){
  var box=document.getElementById('popup-box');
  var cols=['#FFD700','#F0D080','#FFC0D0','#80C0FF','#C0FF80'];
  for(var i=0;i<12;i++){
    var fly=document.createElement('div');fly.className='popup-fly';
    var sz=Math.random()*4+3,tx=(Math.random()-.5)*55,ty=(Math.random()-.5)*55;
    fly.style.cssText='width:'+sz+'px;height:'+sz+'px;background:'+
      cols[Math.floor(Math.random()*cols.length)]+
      ';left:'+(Math.random()*90+5)+'%;top:'+(Math.random()*90+5)+
      '%;--dx:'+tx+'px;--dy:'+ty+'px;animation-duration:'+
      (Math.random()*3+2)+'s;animation-delay:'+(Math.random()*.8)+
      's;opacity:.6;box-shadow:0 0 6px currentColor';
    box.appendChild(fly);flyElems.push(fly);
  }
}
function clearFireflies(){flyElems.forEach(function(e){e.remove();});flyElems=[];}

/* ── 2 BIG BALLOONS from each side ── */
function spawnTwoBigBalloons(){
  var bigSet=['🎈','🎀','💝','🎁','🫧'];
  /* Left big balloon */
  var l=document.createElement('div');
  l.className='big-bal left';
  l.textContent=bigSet[Math.floor(Math.random()*bigSet.length)];
  document.body.appendChild(l);
  l.addEventListener('animationend',function(){l.remove();});
  /* Second left balloon staggered */
  setTimeout(function(){
    var l2=document.createElement('div');
    l2.className='big-bal left';
    l2.textContent=bigSet[Math.floor(Math.random()*bigSet.length)];
    l2.style.left=(8+Math.random()*12)+'vw';
    l2.style.animationDuration='5.5s';
    document.body.appendChild(l2);
    l2.addEventListener('animationend',function(){l2.remove();});
  },600);
  /* Right big balloon — delayed slightly */
  setTimeout(function(){
    var r=document.createElement('div');
    r.className='big-bal right';
    r.textContent=bigSet[Math.floor(Math.random()*bigSet.length)];
    document.body.appendChild(r);
    r.addEventListener('animationend',function(){r.remove();});
  },300);
  /* Second right balloon staggered */
  setTimeout(function(){
    var r2=document.createElement('div');
    r2.className='big-bal right';
    r2.textContent=bigSet[Math.floor(Math.random()*bigSet.length)];
    r2.style.right=(8+Math.random()*12)+'vw';
    r2.style.animationDuration='5s';
    document.body.appendChild(r2);
    r2.addEventListener('animationend',function(){r2.remove();});
  },900);
}

/* Small balloons — both sides */
var BAL=['🎈','🎈','🎈','🎀','🎊','🎉','🎆','🎇','🎁','💝','🫧','🌟','🎈','🎈','🎈'];
function spawnSmallBalloons(n){
  for(var i=0;i<n;i++){
    (function(idx){
      setTimeout(function(){
        var el=document.createElement('div');
        var isR=idx%2!==0;
        el.className=isR?'bal-el r':'bal-el';
        el.textContent=BAL[Math.floor(Math.random()*BAL.length)];
        var x=isR?(55+Math.random()*38):(4+Math.random()*38);
        el.style.left=x+'vw';
        el.style.animationDuration=(2.5+Math.random()*2.5)+'s';
        el.style.animationDelay=(idx*.1)+'s';
        document.body.appendChild(el);
        el.addEventListener('animationend',function(){el.remove();});
      },idx*100);
    })(i);
  }
}

/* ── SPARKLE CANVAS ── */
var canvas=document.getElementById('spark-canvas');
var ctx=canvas.getContext('2d');var sparkles=[];
function resizeCanvas(){canvas.width=window.innerWidth;canvas.height=window.innerHeight;}
resizeCanvas();window.addEventListener('resize',resizeCanvas);
var SC=['#FFD700','#FFB6C1','#F0D080','#FFA0B4','#FFE080','#FFCC80','#A0D8FF'];
function mkSpark(x,y,burst){
  var sp=burst?8:2;
  return{x:x!=null?x:Math.random()*canvas.width,
    y:y!=null?y:Math.random()*canvas.height,
    size:Math.random()*3+.8,
    vx:(Math.random()-.5)*sp,
    vy:burst?(Math.random()-.5)*sp:-Math.random()*1.5-.2,
    alpha:1,decay:Math.random()*.022+.007,
    color:SC[Math.floor(Math.random()*SC.length)]};
}
function burstSparkles(x,y,n){for(var i=0;i<n;i++)sparkles.push(mkSpark(x,y,true));}
function drawStar(cx,cy,o,inn){
  var rot=-Math.PI/2,step=Math.PI/4;ctx.beginPath();
  for(var i=0;i<8;i++){
    var r=i%2===0?o:inn;
    ctx.lineTo(cx+Math.cos(rot)*r,cy+Math.sin(rot)*r);rot+=step;
  }
  ctx.closePath();ctx.fill();
}
(function loop(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  sparkles=sparkles.filter(function(s){return s.alpha>.01;});
  sparkles.forEach(function(s){
    s.x+=s.vx;s.y+=s.vy;s.alpha-=s.decay;
    ctx.save();ctx.globalAlpha=Math.max(0,s.alpha);
    ctx.fillStyle=s.color;ctx.shadowColor=s.color;ctx.shadowBlur=6;
    drawStar(s.x,s.y,s.size,s.size*.35);ctx.restore();
  });
  requestAnimationFrame(loop);
})();
setInterval(function(){sparkles.push(mkSpark());},800);

/* ── SPARK RAIN ── */
var rainI=['✨','⭐','💫','✦','★'],
    rainC=['#FFD700','#F0D080','#FFB6C1','#FFECB8'];
function spawnRainSpark(){
  var el=document.createElement('div');el.className='spark-rain';
  el.textContent=rainI[Math.floor(Math.random()*rainI.length)];
  el.style.cssText='left:'+(Math.random()*94)+'vw;top:-15px;font-size:'+
    (Math.random()*10+8)+'px;color:'+rainC[Math.floor(Math.random()*rainC.length)]+
    ';opacity:'+(Math.random()*.35+.12)+
    ';animation-duration:'+(Math.random()*6+5)+'s;text-shadow:0 0 5px currentColor';
  document.body.appendChild(el);
  el.addEventListener('animationend',function(){el.remove();});
}
setInterval(spawnRainSpark,2500);

/* ── HEARTS ── */
var HI=['💗','💖','🌸','✨'];
function spawnHeart(){
  var el=document.createElement('div');el.className='float-el';
  el.textContent=HI[Math.floor(Math.random()*HI.length)];
  el.style.cssText='left:'+(Math.random()*96)+'vw;bottom:0;font-size:'+
    (Math.random()*11+8)+'px;animation-duration:'+(Math.random()*5+6)+
    's;animation-delay:'+(Math.random()*2)+'s;opacity:'+(Math.random()*.25+.1);
  document.body.appendChild(el);
  el.addEventListener('animationend',function(){el.remove();});
}
setInterval(spawnHeart,5000);

/* ── PETALS ── */
var PC=['#FFB6C1','#FFC8D4','#FFA8B8','#FFD0DC'];
function spawnPetal(){
  var el=document.createElement('div');el.className='petal-el';
  var w=Math.random()*9+5,h=Math.random()*6+4;
  el.style.cssText='top:-16px;left:'+(Math.random()*98)+'vw;width:'+w+
    'px;height:'+h+'px;background:'+PC[Math.floor(Math.random()*PC.length)]+
    ';opacity:'+(Math.random()*.4+.2)+
    ';animation-duration:'+(Math.random()*4+6)+'s;';
  document.body.appendChild(el);
  el.addEventListener('animationend',function(){el.remove();});
}

/* ── INIT ── */
updateCountdown();
setTimeout(function(){burstSparkles(window.innerWidth/2,window.innerHeight/3,10);},700);

/* ══ P1 ROSE PETALS ══ */
var P1_PETALS=['#FFB6C1','#FF9AAF','#FF8FAA','#FFAABF','#FFC8D4'];
function spawnP1Petal(){
  if(cur!==0)return;
  var el=document.createElement('div');
  el.className='p1-petal';
  var w=Math.random()*11+6, h=Math.random()*7+5;
  el.style.cssText='top:-18px;left:'+(Math.random()*98)+'vw;width:'+w+
    'px;height:'+h+'px;background:'+P1_PETALS[Math.floor(Math.random()*P1_PETALS.length)]+
    ';opacity:'+(Math.random()*.55+.25)+
    ';animation-duration:'+(Math.random()*4+6)+'s;position:fixed;z-index:8';
  document.getElementById('p1').appendChild(el);
  el.addEventListener('animationend',function(){el.remove();});
}
setInterval(function(){if(cur===0)spawnP1Petal();},1100);

/* ══ P3 DOVES ══ */
var dovesShown=false;
function spawnDoves(){
  if(dovesShown)return; dovesShown=true;
  var d1=document.createElement('div');d1.className='dove left';d1.textContent='🕊️';
  var d2=document.createElement('div');d2.className='dove right';d2.textContent='🕊️';
  document.body.appendChild(d1);document.body.appendChild(d2);
  setTimeout(function(){d1.remove();},6500);
  setTimeout(function(){d2.remove();},7200);
}

/* ══ P4 REALISTIC FIREWORKS ══ */
var fwCanvas=null, fwCtx=null, fwParticles=[], fwRunning=false, fwTimer=null;

function initFireworks(){
  fwCanvas=document.getElementById('fw-canvas');
  if(!fwCanvas)return;
  fwCanvas.width=window.innerWidth;
  fwCanvas.height=window.innerHeight;
  fwCtx=fwCanvas.getContext('2d');
  fwCtx.clearRect(0,0,fwCanvas.width,fwCanvas.height);
}

function launchFirework(x,y){
  var hue=Math.random()*360;
  var count=80+Math.floor(Math.random()*50);
  for(var i=0;i<count;i++){
    var angle=Math.random()*Math.PI*2;
    var speed=Math.random()*5+1.5;
    fwParticles.push({
      x:x,y:y,
      vx:Math.cos(angle)*speed,
      vy:Math.sin(angle)*speed,
      alpha:1,
      decay:Math.random()*.022+.012,
      size:Math.random()*2.8+.8,
      hue:hue+(Math.random()*60-30),
      bright:Math.random()*20+70,
      gravity:.045
    });
  }
}

function renderFireworks(){
  if(!fwCtx||!fwRunning)return;
  fwCtx.clearRect(0,0,fwCanvas.width,fwCanvas.height);
  fwParticles=fwParticles.filter(function(p){return p.alpha>.01;});
  fwParticles.forEach(function(p){
    p.x+=p.vx; p.y+=p.vy; p.vy+=p.gravity;
    p.vx*=.97; p.vy*=.97;
    p.alpha-=p.decay;
    fwCtx.save();
    fwCtx.globalAlpha=Math.max(0,p.alpha);
    fwCtx.fillStyle='hsl('+p.hue+',100%,'+p.bright+'%)';
    fwCtx.shadowColor='hsl('+p.hue+',100%,70%)';
    fwCtx.shadowBlur=14;
    fwCtx.beginPath();
    fwCtx.arc(p.x,p.y,p.size,0,Math.PI*2);
    fwCtx.fill();
    fwCtx.restore();
  });
  requestAnimationFrame(renderFireworks);
}

function startFireworks(){
  if(!fwCanvas)initFireworks();
  if(!fwCanvas)return;
  fwRunning=true;
  fwCanvas.width=fwCanvas.offsetWidth;
  fwCanvas.height=fwCanvas.offsetHeight||400;
  renderFireworks();
  var shots=[
    [.08,.15],[.92,.15],[.5,.08],
    [.18,.3],[.82,.3],[.35,.1],[.65,.1],
    [.04,.45],[.96,.45],[.5,.28],
    [.25,.2],[.75,.2]
  ];
  // Wave 1
  shots.forEach(function(s,i){
    setTimeout(function(){
      if(!fwCanvas||!fwRunning)return;
      launchFirework(s[0]*fwCanvas.width, s[1]*fwCanvas.height);
    },i*200);
  });
  // Wave 2 — second burst while popup is visible
  setTimeout(function(){
    if(!fwCanvas||!fwRunning)return;
    [[.15,.2],[.85,.2],[.45,.1],[.55,.1],[.1,.4],[.9,.4]].forEach(function(s,i){
      setTimeout(function(){
        if(!fwCanvas||!fwRunning)return;
        launchFirework(s[0]*fwCanvas.width, s[1]*fwCanvas.height);
      },i*220);
    });
  },2600);
  // Wave 3
  setTimeout(function(){
    if(!fwCanvas||!fwRunning)return;
    [[.2,.15],[.8,.15],[.5,.1],[.3,.35],[.7,.35]].forEach(function(s,i){
      setTimeout(function(){
        if(!fwCanvas||!fwRunning)return;
        launchFirework(s[0]*fwCanvas.width, s[1]*fwCanvas.height);
      },i*200);
    });
  },5000);
  fwTimer=setTimeout(function(){fwRunning=false;if(fwCtx)fwCtx.clearRect(0,0,fwCanvas.width,fwCanvas.height);},8000);
}





/* ── Ring sparkle drops ── */
var SPARK_SYMS=['✦','✧','✨','★','✺'];
function spawnRingSpark(){
  if(cur!==0)return;
  var scene=document.getElementById('doves-scene');if(!scene)return;
  var rc=scene.querySelector('.ring-centre');if(!rc)return;
  var el=document.createElement('span');el.className='ring-spark';
  el.textContent=SPARK_SYMS[Math.floor(Math.random()*SPARK_SYMS.length)];
  var sx=(Math.random()-0.5)*24;
  el.style.cssText='--sx:'+sx+'px;color:#FFD080;text-shadow:0 0 6px #FFD040;'
    +'animation-duration:'+(Math.random()*.8+0.6)+'s;'
    +'left:'+(40+Math.random()*20)+'%;top:8px;opacity:.9';
  rc.appendChild(el);
  el.addEventListener('animationend',function(){el.remove();});
}
setInterval(function(){if(cur===0)spawnRingSpark();},320);
