import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-archieve',
  templateUrl: './archieve.component.html',
  styleUrls: ['./archieve.component.css']
})
export class ArchieveComponent implements OnInit {
  note:any;
  Url:string='';
  Title:string='';
  constructor(private http : HttpClient) { }
  unarchieveNotes(i:number):void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=unarchieve&UserId=${this.note[i].UserId}`;
    console.log(this.note[i].UserId)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
  })}
  unArchieveAllNotes():void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=unarchieveall`;
    console.log(this.note.Title)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
  })}


  ngOnInit(): void {
    this.Url =`http://localhost:8080/Netnotetake/UserServlet?operation=archdisplay`;
    console.log(this.Title)
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;

      console.log(data);
    })
  }

}
