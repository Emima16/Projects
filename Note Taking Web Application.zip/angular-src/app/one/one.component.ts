import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit {
  note:any;

  userName:string='';
  userPassword:string='';
  constructor ( private http : HttpClient,private router:Router ) { }
  loginNotes():void{
    if (this.userName=="emima" && this.userPassword=="emima") {
    window.alert("Login Success....\n Welcome to Note Taking Web Appliction...");
    this.router.navigate(['/favourite']);
  } else {
    window.alert("Login Failed....");
  }
  
}
ngOnInit(): void {
}}