import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.css']
})
export class TrashComponent implements OnInit {
  note:any;
  Url:string='';
  Title:string='';
  constructor ( private http : HttpClient ) { }
  restoreNotes(i:number):void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=restore&UserId=${this.note[i].UserId}`;
    console.log(this.note[i].UserId)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
  })}
  deleteallNotes():void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=deleteall`;
    console.log(this.note.Title)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
  })}
  
 binNotes(i:number):void{
  this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=bin&UserId=${this.note[i].UserId}`;
  console.log(this.note[i].UserId)
  window.location.reload();
  this.http.get(this.Url).subscribe((data)=>{
    this.note=data;
})}

 
 ngOnInit(): void {
    this.Url =`http://localhost:8080/Netnotetake/UserServlet?operation=deletedisplay`;
    console.log(this.Title)
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;

      console.log(data);
    })
  }
}
