import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';
import { OneComponent } from './one/one.component'; 
import { RouterModule, Routes } from '@angular/router';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list';
import { SearchComponent } from './search/search.component';
import {MatInputModule} from '@angular/material/input';
import { NotesComponent } from './notes/notes.component';
import { FavouriteComponent } from './favourite/favourite.component';
import { TrashComponent } from './trash/trash.component';
import { ArchieveComponent } from './archieve/archieve.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
const routes: Routes = [
  {path:'dashboard',component:OneComponent},
  {path:'search',component:SearchComponent},
  {path:'notes',component:NotesComponent},
  {path:'favourite',component:FavouriteComponent},
  {path:'trash',component:TrashComponent},
  {path:'archieve',component:ArchieveComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    OneComponent,
    SearchComponent,
    NotesComponent,
    FavouriteComponent,
    TrashComponent,
    ArchieveComponent
  ],
  imports: [
    BrowserModule,MatListModule,  FormsModule,
    AppRoutingModule,ReactiveFormsModule ,
    BrowserAnimationsModule,MatIconModule,MatToolbarModule,RouterModule.forRoot(routes),
    MatButtonModule,MatSidenavModule,MatFormFieldModule,MatInputModule ,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
