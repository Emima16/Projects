import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';



@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {
 
  note:any;
  Comment:string='';
  Title:string='';
  Url:string='';
  constructor ( private http : HttpClient ) { }

  addNotes():void{
    this.Url =`http://localhost:8080/Netnotetake/UserServlet?operation=insert&Title=${this.Title}&Comment=${this.Comment}`;
    console.log(this.Title)
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
      window.location.reload();
      console.log(data);
    })
  } 
 
  ngOnInit(): void {
   
  }

}
