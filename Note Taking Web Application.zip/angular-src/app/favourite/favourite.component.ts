import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent implements OnInit {
  
 public tempUserId:any;
  note:any;
  public temp:any=0;
  Comment:string='';
  Url:string='';
  Title:string='';
constructor ( private http : HttpClient ) { }
tempNotes(id:any){
  this.temp=1;
  localStorage.setItem("UserId",id);
}

  deleteNotes(i:number):void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=delete&UserId=${this.note[i].UserId}`;
    console.log(this.note[i].UserId)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
    })
  }
  editNotes():void{
    this.tempUserId=localStorage.getItem("UserId");
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=update&UserId=${this.tempUserId}&Title=${this.Title}&Comment=${this.Comment}`;
    console.log(this.tempUserId)
    this.temp=0;
    
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
    })
    localStorage.removeItem("UserId");
  }
  



  archieveNotes(i:number):void{
    this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=archieve&UserId=${this.note[i].UserId}`;
    console.log(this.note[i].UserId)
    window.location.reload();
    this.http.get(this.Url).subscribe((data)=>{
      this.note=data;
  })}
  ngOnInit(): void {
    this.http.get('http://localhost:8080/Netnotetake/UserServlet?operation=display').subscribe((data)=>{
      this.note=data;
      console.log(data);
    })
  }

}
