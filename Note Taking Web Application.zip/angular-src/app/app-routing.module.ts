import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OneComponent } from './one/one.component'; 
import { SearchComponent } from './search/search.component';
import { NotesComponent } from './notes/notes.component';
import { FavouriteComponent } from './favourite/favourite.component';
import { TrashComponent } from './trash/trash.component';
import { ArchieveComponent } from './archieve/archieve.component';

const routes: Routes = [  {path:'dashboard',component:OneComponent},
  {path:'search',component:SearchComponent},
  {path:'notes',component:NotesComponent},
  {path:'favourite',component:FavouriteComponent},
  {path:'trash',component:TrashComponent},
  {path:'archieve',component:ArchieveComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
