import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  note:any;
  Url:string='';
  Title:string='';
  constructor ( private http : HttpClient ) { }
  searchNotes():void{
  this.Url = `http://localhost:8080/Netnotetake/UserServlet?operation=get&Title=${this.Title}`;
  console.log(this.Title)
  this.http.get(this.Url).subscribe((data)=>{
  this.note=data;
   
    console.log(data);
  })
 

}
ngOnInit(): void {
}}
