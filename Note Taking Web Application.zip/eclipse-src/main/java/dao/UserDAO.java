package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import org.json.JSONArray;

import model.User;

public class UserDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/demo?useSSL=false";
	private String jdbcUsername = "root";
	private String jdbcPassword = "Emima2001*";
	private static final String INSERT_USERS_SQL = "INSERT INTO users" + "  (Title,Comment) VALUES "
			+ " (?, ?);";
	private static final String SELECT_USER_BY_Title = "select Title,Comment from users where Title = ?";
	private static final String SELECT_ALL_USERS = "select * from users where Trash=0 and Archieve=0";
	private static final String DELETE_USERS_SQL = "delete from users where Title = ?";
	private static final String UPDATE_USERS_SQL = "update users set Title = ?, Comment= ? where  UserId= ?";
	private static final String SELECT_ALL_ARCHI_USERS = " SELECT * FROM users WHERE Archieve = 1 UPDATE users SET archieve=? ";
		
	public UserDAO() {
	}
	
	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(User user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getTitle());
			preparedStatement.setString(2, user.getComment());
		   System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}
	
	public boolean delParticularintrash1(int UserId) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("delete from users where UserId = ? ")) {
			System.out.println(statement);
			statement.setInt(1, UserId);
			System.out.println(statement);
			rowDeleted = statement.executeUpdate() > 0;
			System.out.println(rowDeleted);
		}
		return rowDeleted;
	}
	
	public boolean delAllintrash1() throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("delete from users where Trash=1 and Archieve=0 ")) {
			System.out.println(statement);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public List<User> selectUser(String Title) {
		List<User> users = new ArrayList<>();
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_Title);) {
			preparedStatement.setString(1, Title);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String Comment = rs.getString("Comment");
				users.add(new User(Title, Comment));
				
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public List<User> selectAllUsers() {
		System.out.println("select * from users where Trash=0 and Archieve=0");
		List<User> users = new ArrayList<>();
		try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from users where Trash=0 and Archieve=0");) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int UserId = rs.getInt("UserId");
				String Title = rs.getString("Title");
				String Comment= rs.getString("Comment");
				users.add(new User(UserId,Title,Comment));
			
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	public List<User> selectAllArchiUsers() {
		System.out.println("select * from users where Trash=0 and Archieve=1");
		List<User> users = new ArrayList<>();
		try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from users where Trash=0 and Archieve=1");) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int UserId = rs.getInt("UserId");
				String Title = rs.getString("Title");
				String Comment= rs.getString("Comment");
				users.add(new User(UserId,Title,Comment));
			
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	public List<User> selectAlldeleteUsers() {
		System.out.println("select * from users where Trash=1 and Archieve=0");
		List<User> users = new ArrayList<>();
		try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from users where Trash=1 and Archieve=0");) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int UserId = rs.getInt("UserId");
				String Title = rs.getString("Title");
				String Comment= rs.getString("Comment");
				users.add(new User(UserId,Title,Comment));
			
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	
	public boolean updateUser(User user) throws SQLException {
		System.out.println(UPDATE_USERS_SQL);
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			
			statement.setString(1, user.getTitle());

		    statement.setString(2, user.getComment());
            statement.setInt(3, user.getUserId());
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	public boolean archieveUpdate1(User user) throws SQLException {
		System.out.println("update users set Archieve = ? where UserId = ?");
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("update users set Archieve = ? where UserId  = ?");) {
		    statement.setInt(1, 1);
			statement.setInt(2,user.getUserId());		
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	

public boolean unarchieveAll1(User user) throws SQLException {
		System.out.println("update users set Archieve = ?");
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("update users set Archieve = ? ");) {
		    statement.setInt(1, 0);
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	public boolean deleteUpdate1(User user) throws SQLException {
		System.out.println("update users set Trash = ? where UserId = ?");
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("update users set Trash = ? where UserId = ?");) {
	        statement.setInt(1, 1);
			statement.setInt(2,user.getUserId());		
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	public boolean restoreUpdate1(User user) throws SQLException {
		System.out.println("update users set Trash = ? where UserId = ?");
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("update users set Trash = ? where UserId = ?");) {
	        statement.setInt(1, 0);
			statement.setInt(2,user.getUserId());		
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	public boolean unarchieveUpdate1(User user) throws SQLException {
		System.out.println("update users set Archieve = ? where UserId = ?");
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("update users set Archieve = ? where UserId = ?");) {	
			statement.setInt(1, 0);
			statement.setInt(2,user.getUserId());		
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

}