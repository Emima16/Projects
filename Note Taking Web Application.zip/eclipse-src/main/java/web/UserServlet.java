package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;

import dao.UserDAO;
import model.User;

@WebServlet("/")

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO;
	Gson gson=new Gson();
	
	public void init() {
		userDAO = new UserDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String action=request.getParameter("operation")	;
				try {
			switch (action) {
			case "insert":
				insertUser(request, response);
				break;
			case "delete":
				deleteUpdate(request, response);
				break;
			case "deletedisplay":
				deleteDisplay(request,response);
				break;
			case "get":
				showEditForm(request, response);
				break;
			case "update":
				updateUser(request, response);
				break;
			case "display":
				listUser(request, response);
				break;
			case "archieve":
				archieveUpdate(request,response);
				break;
			case "archdisplay":
				archieveDisplay(request,response);
				break;
			case "restore":
				restoreUpdate(request,response);
				break;
			case "unarchieve":
				unarchieveUpdate(request,response);
				break;
			case "bin":
				delParticularintrash(request,response);
				break;
            case "deleteall":
				delAllintrash(request,response);
				break;
			case "unarchieveall":
				unarchieveAll(request,response);
		
		
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}
	
private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
	   setAccessControlHeaders(response);
	   response.setStatus(HttpServletResponse.SC_OK);
		List<User> listUser = userDAO.selectAllUsers();
		String notejson=this.gson.toJson(listUser);
		PrintWriter out=response.getWriter();
		response.setContentType(notejson);
        out.println(notejson);
		
	}

private void delAllintrash(HttpServletRequest request, HttpServletResponse response)
		throws SQLException, IOException, ServletException {
   setAccessControlHeaders(response);
   response.setStatus(HttpServletResponse.SC_OK);
	userDAO.delAllintrash1();
	
}

private void delParticularintrash(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
	 setAccessControlHeaders(response);
	  response.setStatus(HttpServletResponse.SC_OK);
	 int UserId = Integer.valueOf(request.getParameter("UserId"));
	userDAO.delParticularintrash1(UserId);
	//response.sendRedirect("list");

}
private void unarchieveAll(HttpServletRequest request, HttpServletResponse response)
		throws SQLException, IOException, ServletException {
   setAccessControlHeaders(response);
   response.setStatus(HttpServletResponse.SC_OK);
   String Title = request.getParameter("Title");
  	User book = new User(Title);
	userDAO.unarchieveAll1(book);
	
}
private void archieveDisplay(HttpServletRequest request, HttpServletResponse response)
		throws SQLException, IOException, ServletException {
   setAccessControlHeaders(response);
   response.setStatus(HttpServletResponse.SC_OK);
	List<User> listUser = userDAO.selectAllArchiUsers();
	String notejson=this.gson.toJson(listUser);
	PrintWriter out=response.getWriter();
	response.setContentType(notejson);
	out.println(notejson);
	
}
private void deleteDisplay(HttpServletRequest request, HttpServletResponse response)
		throws SQLException, IOException, ServletException {
   setAccessControlHeaders(response);
   response.setStatus(HttpServletResponse.SC_OK);
	List<User> listUser = userDAO.selectAlldeleteUsers();
	String notejson=this.gson.toJson(listUser);
	PrintWriter out=response.getWriter();
	response.setContentType(notejson);
	out.println(notejson);
}
private void showEditForm(HttpServletRequest request, HttpServletResponse response)
		throws SQLException, ServletException, IOException {
setAccessControlHeaders(response);
response.setStatus(HttpServletResponse.SC_OK);
	String Title = (request.getParameter("Title"));
	List<User> existingUser = userDAO.selectUser(Title);
	String notejson=this.gson.toJson( existingUser);
	PrintWriter out=response.getWriter();
	response.setContentType(notejson);
	out.println(notejson);

}
private void archieveUpdate(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
    int UserId =Integer.valueOf(request.getParameter("UserId"));
	User book = new User(UserId);
	userDAO.archieveUpdate1(book);
	
}
private void deleteUpdate(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
    int UserId = Integer.valueOf(request.getParameter("UserId"));
	User book = new User(UserId);
	userDAO.deleteUpdate1(book);
	
}



private void restoreUpdate(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
	int UserId = Integer.valueOf(request.getParameter("UserId"));
	User book = new User(UserId);
	userDAO.restoreUpdate1(book);
	
}
private void unarchieveUpdate(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
	int UserId = Integer.valueOf(request.getParameter("UserId"));
	User book = new User(UserId);
	userDAO.unarchieveUpdate1(book);

}

private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		setAccessControlHeaders(response);
		response.setStatus(HttpServletResponse.SC_OK	);
		response.setContentType("text/html");
		String Title = request.getParameter("Title");
		String Comment = request.getParameter("Comment");
		User newUser = new User(Title,Comment);
		userDAO.insertUser(newUser);
		
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int UserId = Integer.valueOf(request.getParameter("UserId"));
        String Title = request.getParameter("Title");
		String Comment = request.getParameter("Comment");
		User book = new User(UserId,Title, Comment);
		userDAO.updateUser(book);
		
	}


	protected void doOptions(HttpServletRequest request, HttpServletResponse response)
	          throws ServletException, IOException {
	      setAccessControlHeaders(response);
	      response.setStatus(HttpServletResponse.SC_OK);
	}
	 
	private void setAccessControlHeaders(HttpServletResponse resp) {
	      resp.setHeader("Access-Control-Allow-Origin", "*");
	      resp.setHeader("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS");
	      resp.setHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	      
	  }
}
