package model;


public class User {
	protected int UserId;
	protected String Title;
	protected String Comment;

	
	public User() {
	}
	
	public User(String Title, String Comment) {
		super();
		this.Title = Title;
		this.Comment = Comment;
		
	}

	public User(int UserId, String Title, String Comment) {
		super();
		this.UserId = UserId;
		this.Title = Title;
		this.Comment = Comment;
	}
	public User(String Title) {
		super();
		
		this.Title = Title;
		
	}
	public User(int UserId) {
		super();
		
		this.UserId = UserId;
		
	}

	public int getUserId() {
		return UserId;
	}
	public void setUserId(int UserId) {
		this.UserId = UserId;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String Title) {
		this.Title = Title;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String Comment) {
		this.Comment = Comment;
	}
	
}

